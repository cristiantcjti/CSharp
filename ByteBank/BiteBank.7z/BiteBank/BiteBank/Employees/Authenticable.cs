﻿namespace ByteBank.Employees
{
    internal interface Authenticable
    {
    }
}